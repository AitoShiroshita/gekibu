var num = 0;
var message = " ";
function lot(){
    num = Math.floor(Math.random()*4);
	if(num == 0){
	  message = "いい";
	}else if(num == 1){
	  message="悪くない";
	}else if(num == 2){
	  message="酷い";
	}else{
	  message="普通";
	}
    form1.uranai.value = message;
}
